# carrom
A Carrom Board Game, built on web using Javascript and Html Canvas


Two game modes

Professional Carrom


add a property to coins if they hit the players restricted area after they stopped moving
if the user hits a coin which is in restricted area, its a foul

A round of 5 games between two players is a tournament 

restricted hit should be first hit check